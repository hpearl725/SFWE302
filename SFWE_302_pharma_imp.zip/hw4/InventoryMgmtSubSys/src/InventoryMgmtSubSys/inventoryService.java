/**
 * 
 */
package InventoryMgmtSubSys;

import java.util.Scanner;

/**
 * @author hpear
 *
 */
public interface inventoryService {
	 void lookUpMed(Scanner input);
	 void addNewMed(Scanner input);
	 void removeMed(Scanner input);
	 void changeMed(Scanner input);
}
