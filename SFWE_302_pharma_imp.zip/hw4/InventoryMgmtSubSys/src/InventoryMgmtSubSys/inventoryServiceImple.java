/**
 * 
 */
package InventoryMgmtSubSys;



import java.util.Scanner;

import MedicationInventoryDatabase.MedDatabaseService;
import MedicationInventoryDatabase.MedDatabaseServiceImpl;
import MedicationInventoryDatabase.medication;

/**
 * @author hpear
 *
 */
public class inventoryServiceImple implements inventoryService {
	private static final MedDatabaseService database = new MedDatabaseServiceImpl();
	
	/**
	 * 
	 */
	public inventoryServiceImple() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public void lookUpMed(Scanner input) {
		// TODO Auto-generated method stub
		System.out.println("Please enter the name of the medication:");
		String mName = input.nextLine();
		medication medInfo = database.getMedicationInfo(mName);
		if(medInfo == null) {
			System.out.println("Sorry, the medication: " + mName + " could not be found");
		}
		else {
			medInfo.print();
		}
		
	}

	@Override
	public void addNewMed(Scanner input) {
		// TODO Auto-generated method stub
		System.out.println("Please enter the name of the medication");
		String mName = input.nextLine();
		System.out.println("Please enter expiration in mm/dd/yyyy format: ");
		String expiration = input.nextLine();
		System.out.println("Please enter quantity");
		int quant = input.nextInt();
		boolean res = database.addMedication(mName, expiration, quant);
		if(res == true) {
			System.out.println("Medication added successfully!");
		}
		else{
			System.out.println("Sorry, medication could not be added");
		}
	}

	@Override
	public void removeMed(Scanner input) {
		// TODO Auto-generated method stub
		System.out.println("Please enter name of medication to be removed");
		String mName = input.nextLine();
		boolean res = database.removeMedication(mName);
		if(res == true) {
			System.out.println("Medication removed from system!");
		}
		else {
			System.out.println("Sorry, medication could not be found");
		}
		
	}

	@Override
	public void changeMed(Scanner input) {
		// TODO Auto-generated method stub
		// tbi 
	}

}
