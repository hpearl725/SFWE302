/**
 * 
 */
/**
 * @author hpear
 *
 */
module InventoryMgmtSubSys {
	requires MedicationInventoryDatabase; // medication database
	uses MedicationInventoryDatabase.MedDatabaseServiceImpl; // uses service
	exports InventoryMgmtSubSys; // exports itself 
	provides InventoryMgmtSubSys.inventoryService with InventoryMgmtSubSys.inventoryServiceImple; // provides interface
}