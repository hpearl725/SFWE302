/**
 * 
 */
package MedicationInventoryDatabase;
import java.util.Scanner;

/**
 * @author hpear
 *
 */
// interface for Medication Database Service
public interface MedDatabaseService{
	public boolean addMedication(String name, String expiration, int quantity);
	public medication getMedicationInfo(String name);
	public boolean removeMedication(String name);
	public boolean updateMedication(String name, String[] change);
}
