/**
 * 
 */
package MedicationInventoryDatabase;
import java.util.HashMap;
/**
 * @author hpear
 *
 */
public class MedDatabaseServiceImpl implements MedDatabaseService{
	private final HashMap<String, medication> database;
	public MedDatabaseServiceImpl() { // constructor
		// TODO Auto-generated constructor stub
		this.database = new HashMap<>();
	}

	/**
	 * @param args
	 */
	// main function
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	// gets medication info from database
	public medication getMedicationInfo(String name) {
		if(database.containsKey(name)) {
			return database.get(name);
		}
		else {
			return null;
		}
	}
	// adds medication to database
	public boolean addMedication(String name, String expiration, int quantity) {
		if(database.containsKey(name)) {
			return false;
		}
		else {
			medication med = new medication(name,expiration,quantity);
			database.put(name, med);
			return true;
		}
	}
	// removes medication from database
	public boolean removeMedication(String name) {
		if(!database.containsValue(name)) {
			return false;
		}
		else {
			database.remove(name);
			return true;
		}
	}
	// updates medication information
	public boolean updateMedication(String name, String[] change) {
		return false;
		// tbi
	}

}
