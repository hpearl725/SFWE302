/**
 * 
 */
package MedicationInventoryDatabase;

/**
 * @author hpear
 *
 */
public class medication {

	/**
	 * 
	 */
	private String medName;
	private String expiration;
	private int quantity;
	
	public medication(String medName, String expiration, int quantity) {
		// TODO Auto-generated constructor stub\
		this.medName = medName;
		this.expiration = expiration;
		this.quantity = quantity;
	}
	
	public String getMedName() {
		return medName;
	}
	
	public String getExpiration() {
		return expiration;
	}
	
	public int getQty() {
		return quantity;
	}
	
	public void setMedName(String newName) {
		this.medName = newName;
	}
	
	public void setExpiration(String newExp) {
		this.expiration = newExp;
	}
	
	public void setQty(int Qty) {
		this.quantity = Qty;
	}
	
	public void print() {
		System.out.println("Inventory Information: " + medName);
		System.out.println("Quantity: " + quantity);
		System.out.println("Expiration: " + expiration);
		System.out.println();
	}

	/**
	 * @param args
	 */


}
