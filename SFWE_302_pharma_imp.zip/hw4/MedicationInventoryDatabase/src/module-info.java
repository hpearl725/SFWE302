/**
 * 
 */
/**
 * @author hpear
 *
 */
module MedicationInventoryDatabase {
	exports MedicationInventoryDatabase; // exports self
	provides MedicationInventoryDatabase.MedDatabaseService with MedicationInventoryDatabase.MedDatabaseServiceImpl; // provides service
}