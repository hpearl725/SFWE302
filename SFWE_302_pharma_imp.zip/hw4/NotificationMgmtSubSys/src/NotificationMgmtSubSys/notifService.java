/**
 * 
 */
package NotificationMgmtSubSys;

/**
 * @author hpear
 *
 */

// notifcationService Interface
public interface notifService {
	public boolean sendNotification(String message, String user);
	public boolean sendText(String message, String number);
	public boolean sendEmail(String message, String email);
}
