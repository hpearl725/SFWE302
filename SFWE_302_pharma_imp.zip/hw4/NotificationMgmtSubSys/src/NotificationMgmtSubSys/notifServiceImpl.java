/**
 * 
 */
package NotificationMgmtSubSys;

/**
 * @author hpear
 *
 */

// implementation of notification service
public class notifServiceImpl implements notifService {

	/**
	 * 
	 */
	public notifServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override // sends notification
	public boolean sendNotification(String message, String user) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override  // sends text
	public boolean sendText(String message, String number) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override // sends email
	public boolean sendEmail(String message, String email) {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param args
	 */
	// main methods for notification service
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
