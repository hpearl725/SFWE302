/**
 * 
 */
/**
 * @author hpear
 *
 */
// notification management module 
module NotificationMgmtSubSys {
	exports NotificationMgmtSubSys; // exports self
	provides NotificationMgmtSubSys.notifService with NotificationMgmtSubSys.notifServiceImpl; // provides service
}