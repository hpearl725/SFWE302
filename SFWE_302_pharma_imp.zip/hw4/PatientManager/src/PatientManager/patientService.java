/**
 * 
 */
package PatientManager;

import java.util.Scanner;

/**
 * @author hpear
 *
 */

// interface for Patient Service
public interface patientService {
	public void lookUpPatient(Scanner input);
	public void createNewPatient(Scanner input);
	public void changePatientInfo(Scanner input);
	public void notifyPatient(Scanner input);
	public void removePatient(Scanner input);
}
