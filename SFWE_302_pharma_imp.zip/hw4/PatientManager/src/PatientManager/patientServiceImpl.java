/**
 * 
 */
package PatientManager;

import java.util.Scanner;
import java.util.HashMap;

import patientDatabase.DbService;
import patientDatabase.DbServiceImpl;

/**
 * @author hpear
 *
 */

// implementations of database service 
public class patientServiceImpl implements patientService {
	private static final DbService database = new DbServiceImpl();
	/**
	 * 
	 */
	// constructor
	public patientServiceImpl() {
		// TODO Auto-generated constructor stub
//		System.out.println("hit patient service constructor");
	}

	@Override // looks up patient in database
	public void lookUpPatient(Scanner input) {
		// TODO Auto-generated method stub
        System.out.println("Please enter patient in the following format: First Last");
        String pName = input.nextLine();
        System.out.println("Please enter patient date of birth in the following format: mm/dd/yyyy");
        String pDob = input.nextLine();
        String[] result = database.getPatientInfo(pName, pDob);
        if(result == null) {
        	System.out.println("patient " + pName +", DOB: "+ pDob +" not found");
        }
        else {
        	System.out.println("Patient INFO:");
        	for(String i : result) {
        		System.out.println(i);
        	}
        }
	}

	@Override // creates new patient to be entered into database
	public void createNewPatient(Scanner input) {
		// TODO Auto-generated method stub
    	System.out.println("Please enter patient in the following format: First Last");
        String pName = input.nextLine();
        System.out.println("Please enter patient date of birth in the following format: mm/dd/yyyy");
        String pDob = input.nextLine();
        System.out.println("Please enter patient address");
        String pAdr = input.nextLine();
        System.out.println("Please enter patient gender");
        String pGender = input.nextLine();
        System.out.println("Please enter patient email");
        String pEmail = input.nextLine();
        System.out.println("Please enter patient phone number");
        String cell = input.nextLine();
        database.createNewPatient(pName, pDob, pAdr, pGender, pEmail, cell);
        System.out.println(pName + " added to the database");
        
	}

	@Override // changes patient info in database
	public void changePatientInfo(Scanner input) {
		// TODO Auto-generated method stub
    	System.out.println("Please enter patient in the following format: First Last");
        String pName = input.nextLine();
        System.out.println("Please enter patient date of birth in the following format: mm/dd/yyyy");
        String pDob = input.nextLine();
	    HashMap<String, String> changes = new HashMap<String, String>();
	    System.out.println("Enter new name (leave blank if no change):");
	    String name = input.nextLine();
	    if (!name.isEmpty()) {
	        changes.put("name", name);
	    }
	    
	    System.out.println("Enter new DOB (leave blank if no change):");
	    String age = input.nextLine();
	    if (!age.isEmpty()) {
	        changes.put("dob", age);
	    }
	    
	    System.out.println("Enter new address (leave blank if no change):");
	    String address = input.nextLine();
	    if (!address.isEmpty()) {
	        changes.put("address", address);
	    }
	    
	    System.out.println("Enter new gender (leave blank if no change):");
	    String gender = input.nextLine();
	    if (!gender.isEmpty()) {
	        changes.put("gender", age);
	    }
	    
	    System.out.println("Enter new email (leave blank if no change):");
	    String email = input.nextLine();
	    if (!email.isEmpty()) {
	        changes.put("email", age);
	    }
	    
	    System.out.println("Enter new phone number (leave blank if no change):");
	    String phoneNumber = input.nextLine();
	    if (!age.isEmpty()) {
	        changes.put("phoneNumber", phoneNumber);
	    }
	    // add function to show changes
	    database.updatePatientInfo(pName, pDob, changes);
	    
	}

	@Override // sends notification to patient
	public void notifyPatient(Scanner input) {
		// TODO Auto-generated method stub
		//TBI

	}

	@Override // removes patient from database
	public void removePatient(Scanner input) {
		// TODO Auto-generated method stub
    	System.out.println("Please enter patient in the following format: First Last");
        String pName = input.nextLine();
        System.out.println("Please enter patient date of birth in the following format: mm/dd/yyyy");
        String pDob = input.nextLine();
        database.removePatient(pName, pDob);
	}

	/**
	 * @param args
	 */
	// main method for service implementation 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}



}
