

/**
 * 
 */
/**
 * @author hpear
 *
 */
// module for patient manager
module patientManager {
	requires patientDatabase;// requires patient database
	requires NotificationMgmtSubSys; // requires notification component
	uses patientDatabase.DbServiceImpl; // uses service
	uses NotificationMgmtSubSys.notifService; // uses service
	
	exports PatientManager; // exports self
	provides PatientManager.patientService with PatientManager.patientServiceImpl; // provides service
	
	
}