package main.app;
import main.app.item;

public class Cart {
	private double total = 0.0;
	private item[] cart = {}; 
	
	public Cart() {
		
	}
	
	void addItem() {
		
	}
	
	void removeItem() {
		
	}
	
	void printInvoice() {
		
	}
	
}
