/**
 * 
 */
package main.app;

import java.util.Scanner;

import InventoryMgmtSubSys.inventoryService;
import InventoryMgmtSubSys.inventoryServiceImple;
import PatientManager.patientService;
import PatientManager.patientServiceImpl;

/**
 * @author hpear
 *
 */
public class PharmacyApp {
	private static final inventoryService medDb = new inventoryServiceImple();;
	private static final patientService patientDb = new patientServiceImpl();;
	/**
	 * 
	 */
	public PharmacyApp() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PharmacyApp app = new PharmacyApp();
		Scanner input = new Scanner(System.in);
		String userInput = "";
		String pw = "";
		String user = "";
		
		while(!pw.equals("password") && !user.equals("Admin")) {
			System.out.print("Please enter user name: ");
			user = input.nextLine();
			System.out.print("Please enter password: ");
			pw = input.nextLine();
			if(!pw.equals("password") && !user.equals("Admin")) {
				System.out.print("Invalid login attempt, please try again");
				System.out.print("\n\n");
			}
		}
		
		
		
		while(!userInput.equals("exit")) {
			System.out.print("\n\n");
			homeInstPrint();
			System.out.print("Please enter command here: ");
			userInput = input.nextLine();
			if(userInput.equals("M")) {
				// medication function
				app.medicationPage(input); 
			}
			else if(userInput.equals("P")){
				// patient function
				app.patientPage(input);
			}
			else if(userInput.equals("S")){
				// sales function
				app.salesPage(input);
			}
			else if(userInput.equals("exit")) {
				System.out.println("Goodbye!");
			}
			else {
				System.out.println("Sorry, that was not a valid input.");
				System.out.println("Please try again");
				System.out.println("");
			}
			
		}
		
	}
	
	public void patientPage(Scanner input) {
		String userInput = "";
		while(!userInput.equals("6")) {
			System.out.println();
			System.out.println("Please select from the following option below");
			System.out.println("1: look up patient");
			System.out.println("2: register new patient");
			System.out.println("3: change patient info");
			System.out.println("4: notify patient");
			System.out.println("5: remove patient");
			System.out.println("6: return to main menu");
			System.out.println();
			System.out.print("Please enter command here:");
			userInput = input.nextLine();
			System.out.println();
//			String pName;
//			String pDob;
//			String pAdr;
//			String pGender;
//			String[] pContactInfo;
			switch(userInput) {
			    case "1":
			        patientDb.lookUpPatient(input);
			        break;
			    case "2":
			        patientDb.createNewPatient(input);
			        break;
			    case "3":
			    	patientDb.changePatientInfo(input);
			        break;
			    case "4":
			    	// tbi
			        break;
			    case "5":
			    	patientDb.removePatient(input);
			        break;
			    case "6":
			    	return;
			    default:
			        System.out.println("You entered and invalid input");
			        System.out.println("Please try again");
			        break;
			}
		}
	}
	
	public void medicationPage(Scanner input) {
		String userInput = "";
		while(!userInput.equals("5")){
			System.out.println("1: look up medication");
			System.out.println("2: add medication");
			System.out.println("3: remove medication");
			System.out.println("4: change medication info");
			System.out.println("5: return to main menu");
			System.out.println("");
			System.out.println("Please enter command here:");
			userInput = input.nextLine();
			switch(userInput) {
			    case "1":
			        medDb.lookUpMed(input);
			        break;
			    case "2":
			        medDb.addNewMed(input);;
			        break;
			    case "3":
			    	medDb.removeMed(input);
			        break;
			    case "4":
			    	// tbi
			        break;
			    case "5":
			    	return;
			    default:
			        System.out.println("You entered and invalid input");
			        System.out.println("Please try again");
			        break;
			}
		}
	}
	
	public void salesPage(Scanner input) {
		String userInput = "";
		while(!userInput.equals("4")){
			System.out.println("1: Add item to cart");
			System.out.println("2: Remove item from cart");
			System.out.println("3: Print Invoice");
			System.out.println("4: return to main menu");
			System.out.println("");
			System.out.println("Please enter command here:");
			userInput = input.nextLine();
			switch(userInput) {
			    case "1":
			        //TBI
			        break;
			    case "2":
			        //TBI
			        break;
			    case "3":
			    	//TBI
			        break;
			    case "4":
			    	//TBI
			    	return;
			    default:
			        System.out.println("You entered and invalid input");
			        System.out.println("Please try again");
			        break;
			}
		}
	}
	
	public static void homeInstPrint() {
		System.out.println("Welcome to the Pharmacy Management System!");
		System.out.println("To close the program, enter exit in the command select");
		System.out.println("To access medication inventory, enter: M");
		System.out.println("To access patient information, enter: P ");
		System.out.println();
		
	}
	

}
