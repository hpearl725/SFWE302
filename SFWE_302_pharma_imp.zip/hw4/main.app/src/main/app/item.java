package main.app;

public class item {
	public String name = "";
	public double price = 0.0;
	public int quantity = 1;
	public item(String name, double price,int qty) {
		this.name = name;
		this.price = price;
		this.quantity = qty;
	}
	
}
