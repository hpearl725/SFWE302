/**
 * 
 */
/**
 * @author hpear
 *
 */ // main.app module
module main.app {
	requires InventoryMgmtSubSys; // requires inventory module
	uses InventoryMgmtSubSys.inventoryServiceImple; // uses the service
	
	requires patientManager; // requires patient manager module
	uses PatientManager.patientServiceImpl; // uses the service
}