/**
 * 
 */
/**
 * @author hpear
 *
 */
// modules for patient database
module patientDatabase {
	exports patientDatabase; // exports self
	provides patientDatabase.DbService with patientDatabase.DbServiceImpl; // provides service
}