/**
 * 
 */
package patientDatabase;

import java.util.HashMap;

/**
 * @author hpear
 *
 */

// interface for database service
public interface DbService {
	public String[] getPatientInfo(String name, String dob);
	public void createNewPatient(String name, String dob, String adr, String gender, String email, String phoneNumber);
	public void updatePatientInfo(String name, String dob, HashMap<String, String> changes);
	public void removePatient(String name, String dob);
}
