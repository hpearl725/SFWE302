package patientDatabase;

import java.util.HashMap;
// database service implementation 
public class DbServiceImpl implements DbService {
	
	private HashMap<String, Patient> database;
	
	public DbServiceImpl() { // constructor
		// TODO Auto-generated constructor stub
		this.database = new HashMap<>();
	}

    @Override
    public String[] getPatientInfo(String name, String dob) {
        String key = dob + name; 
        if (database.containsKey(key)) {
            Patient patient = database.get(key);
            String[] patientInfo = {patient.getName(), patient.getDob(), patient.getAdr(),
                    patient.getGender(), patient.getEmail(), patient.getPhoneNumber()};
            return patientInfo;
        }
        return null;
    }

    @Override
    public void createNewPatient(String name, String dob, String adr, String gender, String email, String phoneNumber) {
        String key = dob + name; 
        Patient patient = new Patient(name, dob, adr, gender, email, phoneNumber);
        database.put(key, patient);
    }


    @Override
    public void updatePatientInfo(String name, String dob, HashMap<String, String> changes) {
        String key = dob + name; 
        if (database.containsKey(key)) {
            Patient patient = database.get(key);
            patient.updateInfo(changes);
            database.put(key, patient);
        }
    }


    @Override
    public void removePatient(String name, String dob) {
        String key = dob + name; 
        if (database.containsKey(key)) {
            database.remove(key);
        }
    }

    // main method for testing
    public static void main(String[] args) {
    }

}