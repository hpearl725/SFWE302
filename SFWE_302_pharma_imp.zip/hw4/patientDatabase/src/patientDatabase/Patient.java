package patientDatabase;

import java.util.HashMap;

public class Patient {
    private String name;
    private String dob;
    private String address;
    private String gender;
    private String email;
    private String phoneNumber;

    public Patient(String name, String dob, String address, String gender, String email, String phoneNumber) {
        this.name = name;
        this.dob = dob;
        this.address = address;
        this.gender = gender;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }

    public String getDob() {
        return dob;
    }

    public String getAdr() {
        return address;
    }

    public String getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public Patient getAll(){
    	return this;
	}
    
    public void updateInfo(HashMap<String, String> newInfo) {
        if (newInfo.containsKey("name")) {
            this.name = newInfo.get("name");
        }
        if (newInfo.containsKey("dob")) {
            this.dob = newInfo.get("dob");
        }
        if (newInfo.containsKey("address")) {
            this.address = newInfo.get("address");
        }
        if (newInfo.containsKey("gender")) {
            this.gender = newInfo.get("gender");
        }
        if (newInfo.containsKey("email")) {
            this.email = newInfo.get("email");
        }
        if (newInfo.containsKey("phoneNumber")) {
            this.phoneNumber = newInfo.get("phoneNumber");
        }
    }

}
