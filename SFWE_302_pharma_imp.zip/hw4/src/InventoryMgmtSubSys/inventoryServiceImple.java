/**
 * This is the package declaration for the Inventory Management Subsystem
 */
package InventoryMgmtSubSys;

import java.util.Scanner;

// Importing classes from the Medication Inventory Database package
import MedicationInventoryDatabase.MedDatabaseService;
import MedicationInventoryDatabase.MedDatabaseServiceImpl;
import MedicationInventoryDatabase.medication;

/**
 * This class provides an implementation of the inventoryService interface
 * to manage the inventory of medications.
 * 
 * It implements the methods required by the interface: lookUpMed(), addNewMed(),
 * removeMed() and changeMed().
 */
public class inventoryServiceImple implements inventoryService {
	// Initializing a MedDatabaseService object to access the medication database
	private static final MedDatabaseService database = new MedDatabaseServiceImpl();
		
	/**
	 * Constructor for the class
	 */
	public inventoryServiceImple() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * This method looks up the information for a medication in the database
	 * using the medication name entered by the user.
	 */
	@Override
	public void lookUpMed(Scanner input) {
		// Prompt user for medication name
		System.out.println("Please enter the name of the medication:");
		String mName = input.nextLine();
		
		// Retrieve medication information from database and print it
		medication medInfo = database.getMedicationInfo(mName);
		if(medInfo == null) {
			System.out.println("Sorry, the medication: " + mName + " could not be found");
		}
		else {
			medInfo.print();
		}
	}
	
	/**
	 * This method adds a new medication to the database using the information
	 * entered by the user.
	 */
	@Override
	public void addNewMed(Scanner input) {
		// Prompt user for medication name, expiration date and quantity
		System.out.println("Please enter the name of the medication");
		String mName = input.nextLine();
		System.out.println("Please enter expiration in mm/dd/yyyy format: ");
		String expiration = input.nextLine();
		System.out.println("Please enter quantity");
		int quant = input.nextInt();
		
		// Add medication to database and print confirmation message
		boolean res = database.addMedication(mName, expiration, quant);
		if(res == true) {
			System.out.println("Medication added successfully!");
		}
		else{
			System.out.println("Sorry, medication could not be added");
		}
	}
	
	/**
	 * This method removes a medication from the database using the medication
	 * name entered by the user.
	 */
	@Override
	public void removeMed(Scanner input) {
		// Prompt user for medication name
		System.out.println("Please enter name of medication to be removed");
		String mName = input.nextLine();
		
		// Remove medication from database and print confirmation message
		boolean res = database.removeMedication(mName);
		if(res == true) {
			System.out.println("Medication removed from system!");
		}
		else {
			System.out.println("Sorry, medication could not be found");
		}
	}
	
	/**
	 * This method changes the information for a medication in the database
	 * using the medication name entered by the user.
	 * 
	 * This method is not yet implemented (tbi = to be implemented).
	 */
	@Override
	public void changeMed(Scanner input) {
		// TODO Auto-generated method stub
	}
}
